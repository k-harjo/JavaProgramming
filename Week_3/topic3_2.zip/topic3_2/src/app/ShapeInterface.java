package app;

public interface ShapeInterface {
    public double calculateArea();
}
