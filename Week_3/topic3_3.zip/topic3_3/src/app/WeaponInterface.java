package app;

public interface WeaponInterface {
    void fireWeapon();
    void fireWeapon(int power);
    void activate(boolean enable);
}