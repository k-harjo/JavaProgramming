module SalableProduct {
}