package app;

public interface PersonInterface {
    void walk();
    void run();
    boolean isRunning();
}
