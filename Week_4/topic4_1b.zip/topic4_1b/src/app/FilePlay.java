package app;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

public class FilePlay {
    public static void main(String[] args) {
        String inputFileName = "InUsers.txt";
        String outputFileName = "OutFile.txt";

        int resultCode = copyFile(inputFileName, outputFileName);

        switch (resultCode) {
            case 0:
                System.out.println("File copied successfully.");
                break;
            case -1:
                System.err.println("File Not Found: Input file does not exist.");
                break;
            case -2:
                System.err.println("I/O Error: An error occurred during file copy.");
                break;
        }
    }

    private static int copyFile(String inputFileName, String outputFileName) {
        BufferedReader reader = null;
        BufferedWriter writer = null;

        try {
            reader = new BufferedReader(new FileReader(inputFileName));
            writer = new BufferedWriter(new FileWriter(outputFileName));

            int c;
            while ((c = reader.read()) != -1) {
                writer.write(c);
            }

            return 0; // File copied successfully
        } catch (FileNotFoundException e) {
            return -1; // Input file not found
        } catch (IOException e) {
            return -2; // I/O error during file copy
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
