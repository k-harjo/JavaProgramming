package app;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

public class FilePlay {
    public static void main(String[] args) {
        String inputFileName = "InUsers.txt";
        String outputFileName = "OutFile.txt";

        try {
            copyFile(inputFileName, outputFileName);
            System.out.println("File copied successfully.");
        } catch (FileNotFoundException e) {
            System.err.println("File Not Found: Input file does not exist.");
        } catch (IOException e) {
            System.err.println("I/O Error: An error occurred during file copy.");
        }
    }

    private static void copyFile(String inputFileName, String outputFileName)
            throws FileNotFoundException, IOException {
        BufferedReader reader = null;
        BufferedWriter writer = null;

        try {
            reader = new BufferedReader(new FileReader(inputFileName));
            writer = new BufferedWriter(new FileWriter(outputFileName));

            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split("\\|");
                if (tokens.length >= 3) {
                    String firstName = tokens[0];
                    String lastName = tokens[1];
                    String age = tokens[2];
                    String formattedLine = String.format("Name is %s %s of age %s%n", firstName, lastName, age);
                    writer.write(formattedLine);
                }
            }
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
