package app;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Car {
    private int year;
    private String make;
    private String model;
    private double odometer;
    private double engineLiters;

    @JsonCreator
    public Car(
        @JsonProperty("year") int year,
        @JsonProperty("make") String make,
        @JsonProperty("model") String model,
        @JsonProperty("odometer") double odometer,
        @JsonProperty("engineLiters") double engineLiters
    ) {
        this.year = year;
        this.make = make;
        this.model = model;
        this.odometer = odometer;
        this.engineLiters = engineLiters;
    }


    // Getter methods
    public int getYear() {
        return year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public double getOdometer() {
        return odometer;
    }

    public double getEngineLiters() {
        return engineLiters;
    }

    // Setter methods
    public void setYear(int year) {
        this.year = year;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setOdometer(double odometer) {
        this.odometer = odometer;
    }

    public void setEngineLiters(double engineLiters) {
        this.engineLiters = engineLiters;
    }

    public static void main(String[] args) {
        // Create a Car object using the non-default constructor
        Car myCar = new Car(2023, "Toyota", "Camry", 25000.5, 2.5);

        // Access properties and print them
        System.out.println("Year: " + myCar.getYear());
        System.out.println("Make: " + myCar.getMake());
        System.out.println("Model: " + myCar.getModel());
        System.out.println("Odometer: " + myCar.getOdometer() + " miles");
        System.out.println("Engine Liters: " + myCar.getEngineLiters() + " L");
    }
}
