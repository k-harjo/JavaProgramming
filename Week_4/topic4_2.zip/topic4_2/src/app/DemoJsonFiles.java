package app;

import java.io.File;
import java.io.IOException;


import com.fasterxml.jackson.databind.ObjectMapper;

public class DemoJsonFiles {
    public static void main(String[] args) {
        // Create an array of Car objects
        Car[] cars = {
            new Car(2022, "Toyota", "Camry", 10000, 2.5),
            new Car(2021, "Honda", "Civic", 8000, 1.8),
            new Car(2020, "Ford", "Fusion", 12000, 2.0)
        };

        // Specify the output JSON file path
        String jsonFilePath = "cars.json";

        // Convert the array of Cars to JSON and write to a file
        saveToFile(cars, jsonFilePath);

        // Read the JSON data from the file and convert it back to an array of Cars
        Car[] loadedCars = readFromFile(jsonFilePath);

        if (loadedCars != null) {
            System.out.println("Cars loaded from JSON file:");
            for (Car car : loadedCars) {
                System.out.println("Year: " + car.getYear());
                System.out.println("Make: " + car.getMake());
                System.out.println("Model: " + car.getModel());
                System.out.println("Odometer: " + car.getOdometer());
                System.out.println("Engine Liters: " + car.getEngineLiters());
                System.out.println();
            }
        } else {
            System.out.println("Failed to load Cars from JSON file.");
        }
    }

    // Method to serialize an array of Cars to JSON and write to a file
    public static void saveToFile(Car[] cars, String filePath) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            objectMapper.writeValue(new File(filePath), cars);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Car[] readFromFile(String filePath) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            return objectMapper.readValue(new File(filePath), Car[].class);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
