package app;


public class MyThread1 extends Thread {
    @Override
    public void run() {
        System.out.println("MyThread1 is running.");
    }
}
