module Topic6_2 {
}