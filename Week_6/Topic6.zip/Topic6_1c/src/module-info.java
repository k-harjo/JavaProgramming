module Topic6_1c {
}