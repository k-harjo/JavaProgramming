module Topic6_1b {
}