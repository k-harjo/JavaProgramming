module SalableProduct {
	exports app;
	exports salableProduct;
	requires com.fasterxml.jackson.databind;
	requires com.fasterxml.jackson.annotation;
}