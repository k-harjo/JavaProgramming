package app;

public abstract class Weapon {
    public abstract void fireWeapon(int power);
    public abstract void activate(boolean enable);
}