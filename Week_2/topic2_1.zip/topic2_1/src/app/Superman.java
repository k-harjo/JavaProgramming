package app;

import java.util.Random;

public class Superman extends SuperHero {
    public Superman(int health) {
        super("Superman", health);
    }

}